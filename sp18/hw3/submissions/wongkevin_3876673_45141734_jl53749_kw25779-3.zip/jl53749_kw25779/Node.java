//package homework3;

public class Node {
	String name;
	int amount;
	public Node (String s, int i ) {
		name = s;
		amount = i;
	}
}
