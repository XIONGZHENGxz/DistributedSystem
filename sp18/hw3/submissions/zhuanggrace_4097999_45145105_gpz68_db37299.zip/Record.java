
public class Record {
    public String studentName;
    public String bookName;
    public Integer recordID;
    
    public Record(String student, String book, Integer i) {
        studentName = student;
        bookName = book;
        recordID = i;
    }
}

