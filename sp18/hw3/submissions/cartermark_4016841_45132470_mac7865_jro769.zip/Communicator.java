
public interface Communicator {
	
//	void borrow_book(String student_name, String book_name);
//	void return_book(String record_id);
//	void list(String student_name);
//	void inventory();
//	void exit();
	String send_message(String message);
};
