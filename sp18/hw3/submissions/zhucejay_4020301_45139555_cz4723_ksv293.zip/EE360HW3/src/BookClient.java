import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.*;
public class BookClient {
  private static final int BUFFER_SIZE = 2048;
  
  public static void main (String[] args) {
    String hostAddress;
    int tcpPort;
    int udpPort;
    int clientId;
    
    DatagramSocket udpSocket;
    Socket tcpSocket;
    InetAddress ia;
    String mode = "U";

    if (args.length != 2) {
      System.out.println("ERROR: Provide 2 arguments: commandFile, clientId");
      System.out.println("\t(1) <command-file>: file with commands to the server");
      System.out.println("\t(2) client id: an integer between 1..9");
      System.exit(-1);
    }

    String commandFile = args[0];
    clientId = Integer.parseInt(args[1]);
    hostAddress = "localhost";
    tcpPort = 7000;// hardcoded -- must match the server's tcp port
    udpPort = 8000;// hardcoded -- must match the server's udp port

    try {
    	ia = InetAddress.getByName(hostAddress);
    	udpSocket = new DatagramSocket();
    	tcpSocket = new Socket(ia, tcpPort);
    	
    	PrintWriter tcpWriter = new PrintWriter(tcpSocket.getOutputStream());	// Writes to server
    	Scanner tcpReader = new Scanner(tcpSocket.getInputStream());	// Reads from server
    	
    	// Clear output file
    	StringBuilder fileNameBuilder = new StringBuilder();
  	  	fileNameBuilder.append("out");
  	  	fileNameBuilder.append("_");
  	  	fileNameBuilder.append(clientId);
  	  	fileNameBuilder.append(".txt");
  	  	PrintWriter clearWriter = new PrintWriter(fileNameBuilder.toString(), "UTF-8");
  	  	clearWriter.print("");
  	  	clearWriter.close();
    	
  	  	// Parse command file
        Scanner sc = new Scanner(new FileReader(commandFile));
        while(sc.hasNextLine()) {
          String cmd = sc.nextLine();
          List<String> tokens = new ArrayList<String>();
          
          Pattern regex = Pattern.compile("[^\\s\"']+|\"[^\"]*\"|'[^']*'");
          Matcher regexMatcher = regex.matcher(cmd);
          while(regexMatcher.find()) {
        	  tokens.add(regexMatcher.group());
          }
          
          // Send each command to server, must send before socket is closed by exit to avoid exception
          if(mode.equals("U")) {
          	sendCommandUDP(ia, udpSocket, udpPort, cmd, clientId);
          }
          else if(mode.equals("T")) {
          	sendCommandTCP(tcpWriter, tcpReader, cmd, clientId);
          }
          
          // Set mode or exit
          if (tokens.get(0).equals("setmode")) {
        	if(tokens.get(1).equals("U")) {
        		mode = "U";
        	}
        	else if(tokens.get(1).equals("T")) {
        		mode = "T";
        	}
          } else if (tokens.get(0).equals("borrow")) {
        	  // Handled by server
          } else if (tokens.get(0).equals("return")) {
        	  // Handled by server
          } else if (tokens.get(0).equals("inventory")) {
        	  // Handled by server
          } else if (tokens.get(0).equals("list")) {
        	  // Handled by server
          } else if (tokens.get(0).equals("exit")) {
        	  // Server automatically updates inventory file, no need to modify here
        	  udpSocket.close();
        	  tcpSocket.close();
          } else {
            System.out.println("ERROR: No such command");
          }
        }
        
        // Delete newline at end of output file from UDP and TCP
        Scanner copyReader = new Scanner(new FileReader(fileNameBuilder.toString()));
        StringBuilder copyBuilder = new StringBuilder();
        while(copyReader.hasNextLine()) {
        	String next = copyReader.nextLine();
        	if(!next.equals("")) {
        		copyBuilder.append(next);
        		copyBuilder.append("\n");
        	}
        }
        copyBuilder.deleteCharAt(copyBuilder.lastIndexOf("\n"));
        PrintWriter copyWriter = new PrintWriter(fileNameBuilder.toString(), "UTF-8");
        copyWriter.print(copyBuilder.toString());
        copyWriter.close();
    } catch (IOException e) {
    e.printStackTrace();
    }
  }
  
  private static void sendCommandUDP(InetAddress ia, DatagramSocket socket, int port, String command, int clientId) {
	  byte[] sendBytes = command.getBytes();
	  byte[] receiveBytes = new byte[BUFFER_SIZE];
	  
	  StringBuilder fileNameBuilder = new StringBuilder();
	  fileNameBuilder.append("out");
	  fileNameBuilder.append("_");
	  fileNameBuilder.append(clientId);
	  fileNameBuilder.append(".txt");
	  
	  try {
		  PrintWriter outFileWriter = new PrintWriter(new FileWriter(fileNameBuilder.toString(), true));
		  
		  DatagramPacket sendPacket = new DatagramPacket(sendBytes, sendBytes.length, ia, port);
		  socket.send(sendPacket);
		  DatagramPacket receivePacket = new DatagramPacket(receiveBytes, receiveBytes.length);
		  socket.receive(receivePacket);
		  
		  String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
		  
		  // Store entire response in output file
		  outFileWriter.print(response);
		  outFileWriter.close();
	  }
	  catch(IOException e) {
	  e.printStackTrace();
	  }
  }
  
  private static void sendCommandTCP(PrintWriter writer, Scanner reader, String command, int clientId) {
	  writer.println(command);
	  writer.flush();
	  
	  StringBuilder fileNameBuilder = new StringBuilder();
	  fileNameBuilder.append("out");
	  fileNameBuilder.append("_");
	  fileNameBuilder.append(clientId);
	  fileNameBuilder.append(".txt");
	  
	  try {
		PrintWriter outFileWriter = new PrintWriter(new FileWriter(fileNameBuilder.toString(), true));
		StringBuilder responseBuilder = new StringBuilder();
		
		while(reader.hasNextLine()) {		// Must use while loop with nextLine() because the format of response has spaces
			  String responseLine = reader.nextLine();
			  if(responseLine.equals("end")) {
				  break;					// This will not store "end" in output file because it breaks while loop
			  }
			  if(!responseLine.equals("")){		// Skips setmode, exit, and newlines between responses!
				  responseBuilder.append(responseLine);
				  responseBuilder.append("\n");
			  }
		}
		outFileWriter.print(responseBuilder.toString());
		outFileWriter.flush();
		outFileWriter.close();
	  } catch (IOException e) {
		e.printStackTrace();
	  }
  }
}
