import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Library {
	private final Map<String, Integer> inventory;
	private final Map<Integer, Request> borrowRecord;
	private final Map<String, List<Request>> studentRecords;
	private final AtomicInteger requestNumber;
	
	public Library(String fileName) {
		this.inventory = new LinkedHashMap<>();
		this.borrowRecord = new HashMap<>();
		this.studentRecords = new HashMap<>();
		this.requestNumber = new AtomicInteger(1);
		
		buildInventory(fileName);
	}
	
	public synchronized String borrowBook(String student, String book) {
		Integer numCopies = inventory.get(book);
		
		if(numCopies == null) {
			return "Request Failed - We do not have this book\n";
		}
		if(numCopies == 0) {
			return "Request Failed - Book not available\n";
		}
		// Else the book is available
		int reqID = requestNumber.getAndIncrement();	// Obtain request ID
		
		Request request = new Request(reqID, student, book);	// Create request
		
		inventory.replace(book, numCopies - 1);		// Decrement and update inventory
		updateInventory();
		
		borrowRecord.put(reqID, request);	// Add to borrow records
		
		// Add to student records
		if(studentRecords.containsKey(student)) {
			List<Request> requestList = studentRecords.get(student);
			requestList.add(request);
		}
		else {
			List<Request> requestList = new ArrayList<>();
			requestList.add(request);
			studentRecords.put(student, requestList);
		}
		
		return "Your request has been approved, " + request.getID() + " " + request.getStudent() + " " + request.getBook() + "\n";
	}
	
	public synchronized String returnBook(int requestID) {
		if(borrowRecord.containsKey(requestID)) {
			Request request = borrowRecord.get(requestID);	// Find request associated with ID	
			
			Integer numCopies = inventory.get(request.getBook());	
			inventory.replace(request.getBook(), numCopies + 1);	// Increment and update inventory
			updateInventory();
			
			borrowRecord.remove(requestID);		// Remove request from borrow records
			
			List<Request> requestList = studentRecords.get(request.getStudent());	// Remove request from student records
			requestList.remove(request);
			
			return requestID + " is returned" + "\n";
		}
		else {
			return requestID + " not found, no such borrow record" + "\n";
		}
	}
	
	public synchronized String listForStudent(String student) {
		if(studentRecords.containsKey(student)) {
			List<Request> requestList = studentRecords.get(student);
			if(requestList.size() == 0) {
				return "No record found for " + student + "\n";
			}
			StringBuilder builder = new StringBuilder();
			
			for(Request r: requestList) {
				builder.append(r.getID());
				builder.append(" ");
				builder.append(r.getBook());
				builder.append("\n");
			}
			return builder.toString();
		}
		else {
			return "No record found for " + student + "\n";
		}
	}
	
	public synchronized String takeInventory() {
		Set<String> invKeySet = inventory.keySet();
		StringBuilder builder = new StringBuilder();
		for(String s: invKeySet) {
			builder.append(s);
			builder.append(" ");
			builder.append(inventory.get(s));
			builder.append("\n");
		}
		return builder.toString();
	}
	
	private void buildInventory(String fileName) {
		try {
	    	Scanner sc = new Scanner(new FileReader(fileName));
	    	
	    	while(sc.hasNextLine()) {
	    		String input = sc.nextLine();
	    		List<String> tokens = new ArrayList<String>();
	    		
	            Pattern regex = Pattern.compile("[^\\s\"']+|\"[^\"]*\"|'[^']*'");
	            Matcher regexMatcher = regex.matcher(input);
	            while(regexMatcher.find()) {
	          	  tokens.add(regexMatcher.group());
	            }
	            
	            inventory.put(tokens.get(0), Integer.parseInt(tokens.get(1)));
	    	}
	    	updateInventory();
	    } catch (FileNotFoundException e) {
	    e.printStackTrace();
	    }
	}
	
	private void updateInventory() {	
	  try {
		PrintWriter writer = new PrintWriter("inventory.txt", "UTF-8");
		Set<String> invKeySet = inventory.keySet();
		StringBuilder builder = new StringBuilder();
		for(String s: invKeySet) {
			builder.append(s);
			builder.append(" ");
			builder.append(inventory.get(s));
			builder.append("\n");
		}
		builder.deleteCharAt(builder.lastIndexOf("\n"));
		writer.print(builder.toString());
		writer.close();
	  } catch (FileNotFoundException e) {
		e.printStackTrace();
	  } catch (UnsupportedEncodingException e) {
		e.printStackTrace();
	  }
	}
}
