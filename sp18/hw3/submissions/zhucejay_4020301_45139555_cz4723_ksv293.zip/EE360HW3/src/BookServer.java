import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;
import java.net.*;

public class BookServer {
  public static void main (String[] args) {
    int tcpPort;
    int udpPort;
    if (args.length != 1) {
      System.out.println("ERROR: Provide 1 argument: input file containing initial inventory");
      System.exit(-1);
    }
    String fileName = args[0];
    tcpPort = 7000;
    udpPort = 8000;
    
    Library library = new Library(fileName);

    // TODO: Handle request from clients
    
    // UDP and TCP Listeners
    UDPListener udpListener = new UDPListener(udpPort, library);
    udpListener.start();
    
    TCPListener tcpListener = new TCPListener(tcpPort, library);
    tcpListener.start();
  }
  
  /* ----- UDP and TCP Listener Classes ----- */
    
  private static class UDPListener extends Thread {
    private static final int BUFFER_SIZE = 2048;

    private DatagramSocket socket;
    private Library library;
    private byte[] receiveBytes;

    UDPListener(int port, Library library) {
      this.library = library;
      this.receiveBytes = new byte[BUFFER_SIZE];

      try {
        this.socket = new DatagramSocket(port);
      } catch (SocketException e) {
        e.printStackTrace();
      }
    }

    @Override
    public void run() {
      DatagramPacket receivePacket;

      while (true) {
        receivePacket = new DatagramPacket(receiveBytes, receiveBytes.length);

        try {
          socket.receive(receivePacket);
          
          Thread worker = new Thread(new UDPWorker(library, socket, receivePacket));
          worker.start();
        } catch (IOException e) {
          e.printStackTrace();
          socket.close();
          return;
        }
      }
    }
  }

  private static class TCPListener extends Thread {
    private ServerSocket socket;
    private Library library;

    TCPListener(int port, Library library) {
      this.library = library;
      try {
        this.socket = new ServerSocket(port);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    @Override
    public void run() {
      while (true) {
        try {
          Socket receiveSocket = socket.accept();

          Thread worker = new Thread(new TCPWorker(library, receiveSocket));
          worker.start();
        } catch (IOException e) {
          e.printStackTrace();
          return;
        }
      }
    }
  }
      
  /* ----- UDP and TCP Workers ----- */
  private static class UDPWorker implements Runnable {
	private final Library library;
	private final DatagramSocket socket;
    private final DatagramPacket packet;

    UDPWorker(Library library, DatagramSocket socket, DatagramPacket packet) {
      this.library = library;
      this.socket = socket;
      this.packet = packet;
    }

    @Override
    public void run() {
      // Retrieve command
      String command;

      try {
        command = new String(packet.getData(), 0, packet.getLength(), "UTF-8");
      } catch (UnsupportedEncodingException e) {
        e.printStackTrace();
        return;
      }

      // Run command
      String response = runCommand(library, command);
      if (response == null) {
        System.out.println("ERROR: UNKNOWN COMMAND - " + command);
        return;
      }

      // Send response
      try {
        byte[] returnBytes = response.getBytes("UTF-8");
        DatagramPacket returnPacket = new DatagramPacket(returnBytes, returnBytes.length, packet.getAddress(), packet.getPort());
	    socket.send(returnPacket);
      } catch (IOException e) {
        System.out.println("ERROR: UNABLE TO SEND RESPONSE: " + e);
      }
    }
  }

  private static class TCPWorker implements Runnable {
	private final Library library;
    private final Socket socket;

    TCPWorker(Library library, Socket socket) {
      this.library = library;
      this.socket = socket;
    }

    @Override
    public void run() {
      try {
        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter writer = new PrintWriter(socket.getOutputStream());

        while (true) {
          // Retrieve command
          String command = reader.readLine();
          if (command == null)
            break;

          // Run command
          String response = runCommand(library, command);
          if (response == null) {
            System.out.println("ERROR: UNKNOWN COMMAND - " + command);
            continue;
          }
          
          response += "\nend";		// One line marks end of response
          // Send response
          writer.println(response);
          writer.flush();
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  private static String runCommand(Library library, String command) {
    List<String> tokens = new ArrayList<String>();
		
    Pattern regex = Pattern.compile("[^\\s\"']+|\"[^\"]*\"|'[^']*'");
    Matcher regexMatcher = regex.matcher(command);
    while(regexMatcher.find()) {
      tokens.add(regexMatcher.group());
    }
    switch (tokens.get(0).trim()) {
      case "borrow":
        return library.borrowBook(tokens.get(1).trim(), tokens.get(2).trim());

      case "return":
        return library.returnBook(Integer.parseInt(tokens.get(1).trim()));

      case "list":
        return library.listForStudent(tokens.get(1).trim());

      case "inventory":
        return library.takeInventory();
        
      case "setmode":
    	return "";
    	
      case "exit":
    	return "";
    	
      default:
        return null;
    }
  }
}
