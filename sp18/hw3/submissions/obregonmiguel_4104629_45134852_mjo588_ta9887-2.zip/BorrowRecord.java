
public class BorrowRecord {
	private String book;
	private String student;
	
	public BorrowRecord(String book, String student) {
		this.book = book;
		this.student = student;
	}
	
	public String getBook() {
		return book;
	}
	
	public String getStudent() {
		return student;
	}
}
