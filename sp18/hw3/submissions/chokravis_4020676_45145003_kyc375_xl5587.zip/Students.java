import java.util.Map;

public class Students {
    public String name;
    public Map<Integer, String> bookID;
    public Students(String name, Map<Integer, String> bookID){
        this.name = name;
        this.bookID = bookID;
    }
}
