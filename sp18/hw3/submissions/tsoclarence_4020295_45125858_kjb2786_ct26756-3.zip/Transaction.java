
public class Transaction {
	String student;
	String book;
	
	public Transaction(String name, String title){
		student = name;
		book = title;
	}

}
