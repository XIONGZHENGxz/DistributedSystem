public class Record {
	String studentName;
	String bookName;
	int recordID;

	public Record(String s, String b, int id) {
		studentName = s;
		bookName = b;
		recordID = id;
	}
}