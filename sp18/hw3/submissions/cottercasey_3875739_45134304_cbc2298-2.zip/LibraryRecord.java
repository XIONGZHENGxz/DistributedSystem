public class LibraryRecord {
    int record_ID;
    String book;
    String name;

    public LibraryRecord(int i, String b, String n) {
        record_ID = i;
        book = b;
        name = n;
    }
}