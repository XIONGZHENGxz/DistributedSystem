public interface Transmitter {
	String transmit_String(String str);
};