
public class Book {
	String name;
	int checked_in;
	int id;
	
	public Book(String n, int num) {
		name = n;
		checked_in = num;
		id = num;
	}
}
