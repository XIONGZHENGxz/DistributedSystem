import java.util.ArrayList;

public class BookHolder {
	String name;
	ArrayList<Book> books = new ArrayList<Book>();
	
	public BookHolder(String n) {
		name = n;
	}
}
