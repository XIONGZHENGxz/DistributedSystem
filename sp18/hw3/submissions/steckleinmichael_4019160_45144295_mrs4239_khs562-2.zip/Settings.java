/*
 * EID's of group members
 * mrs4239
 * khs562
 */

public class Settings {
	public static int UPD_PORT = 8000;
	public static int TCP_PORT = 7000;
	public static String HOSTNAME = "localhost";
	public static int MAX_BUFF_LEN = 4096;
}
